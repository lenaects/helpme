package com.example.pr22_2versia2

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class PokemonActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pokemon)
    }

    private fun getResualt()
    {


        val url = "https://pokeapi.co/api/v2/pokemon/1/"

        val queue = Volley.newRequestQueue(this)

        val stringRequest = StringRequest(
            Request.Method.GET, url,
            { response ->
                val textInfoSet :TextView= findViewById(R.id.textinfo)
                val txt = JSONObject(response)
                //val json = JSONObject(response.body?.sting())
                val height = txt.getJSONObject("ability").getString("name")

                textInfoSet.text = height.toString()

                Log.d("MyLog", "Volley: $response")
            },
            { error ->



                Log.d("MyLog", "Volley error: ${error.message}")
            })

        queue.add(stringRequest)

    }

    fun getResultBut(view: View) {
        getResualt()
    }
}