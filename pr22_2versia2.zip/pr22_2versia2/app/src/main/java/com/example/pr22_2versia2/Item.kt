package com.example.pr22_2versia2
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity (tableName = "items")

//коллоны
data class Item(

    //ид
    @PrimaryKey(autoGenerate = true)
    var id: Int? = null,

    //способность
    @ColumnInfo(name = "ability")
    var abiliti: String,
    //рост
    @ColumnInfo(name = "height")
    var height: String,
    //вес
    @ColumnInfo(name = "weight ")
    var weight: String,


    )